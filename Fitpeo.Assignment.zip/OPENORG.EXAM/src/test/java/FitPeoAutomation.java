
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import java.time.Duration;
public class FitPeoAutomation {
    public static void main(String[] args) {
        // Set up the WebDriver
        System.setProperty("webdriver.chrome.driver","C:\\Users\\iamtr\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe"); // Update the path to your chromedriver
        WebDriver driver = new ChromeDriver();
        try {
            // Navigate to the FitPeo Homepage
            driver.get("https://www.fitpeo.com/");

            // Navigate to the Revenue Calculator Page
            driver.get("https://fitpeo.com/revenue-calculator");

            // Scroll Down to the Slider section
            WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
            WebElement slider = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='range']")));
            ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", slider);

            // Adjust the Slider to 820
            Actions moveSlider = new Actions(driver);
            WebElement sliderValueDisplay = driver.findElement(By.id("slider-value")); // Update with the correct ID
            int desiredValue = 820;
            moveSlider.clickAndHold(slider).moveByOffset((desiredValue - Integer.parseInt(slider.getAttribute("value"))) * 3, 0).release().perform();  // Adjust the offset as necessary

            // Ensure the value is updated
            assert sliderValueDisplay.getAttribute("value").equals(String.valueOf(desiredValue));

            // Update the Text Field to 560
            WebElement textField = driver.findElement(By.xpath("//input[@type='text']"));  // Update with the correct XPATH
            textField.clear();
            textField.sendKeys("560");
            textField.sendKeys(org.openqa.selenium.Keys.RETURN);

            // Validate Slider Value
            assert slider.getAttribute("value").equals("560");

            // Scroll down and select CPT Codes
            String[] checkboxes = {"99091", "99453", "99454", "99474"};
            for (String code : checkboxes) {
                WebElement checkbox = driver.findElement(By.id("cpt-" + code));  // Update with the correct ID format
                if (!checkbox.isSelected()) {
                    checkbox.click();
                }
            }

            // Validate Total Recurring Reimbursement
            WebElement totalReimbursement = driver.findElement(By.id("total-reimbursement"));  // Update with the correct ID
            assert totalReimbursement.getText().equals("$110700");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }



    }
}